import Papa from 'papaparse'
import * as XLSX from 'xlsx'

interface ScrapeResult {
  name: string
  address: string
  email: string
  phone: string
  links: string[]
}

export const exportToCSV = (data: ScrapeResult[], filename: string) => {
  const csv = Papa.unparse(
    data.map((item) => ({
      Name: item.name,
      Address: item.address,
      Email: item.email,
      Phone: item.phone,
      Links: item.links.join(';'),
    }))
  )
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  link.click()
  URL.revokeObjectURL(link.href)
}

export const exportToTXT = (data: ScrapeResult[], filename: string) => {
  const txt = data
    .map(
      (item) =>
        `Name: ${item.name}\nAddress: ${item.address}\nEmail: ${item.email}\nPhone: ${item.phone}\nLinks: ${item.links.join(', ')}\n---`
    )
    .join('\n')
  const blob = new Blob([txt], { type: 'text/plain;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  link.click()
  URL.revokeObjectURL(link.href)
}

export const exportToExcel = (data: ScrapeResult[], filename: string) => {
  const ws = XLSX.utils.json_to_sheet(
    data.map((item) => ({
      Name: item.name,
      Address: item.address,
      Email: item.email,
      Phone: item.phone,
      Links: item.links.join(';'),
    }))
  )
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Results')
  XLSX.writeFile(wb, filename)
}