import { create } from 'zustand'

interface ScrapeResult {
  name: string
  address: string
  email: string
  phone: string
  links: string[]
}

interface SearchState {
  results: ScrapeResult[]
  isLoading: boolean
  error: string | null
  setResults: (results: ScrapeResult[]) => void
  setIsLoading: (isLoading: boolean) => void
  setError: (error: string | null) => void
}

export const useSearchStore = create<SearchState>((set) => ({
  results: [],
  isLoading: false,
  error: null,
  setResults: (results) => set({ results }),
  setIsLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
}))