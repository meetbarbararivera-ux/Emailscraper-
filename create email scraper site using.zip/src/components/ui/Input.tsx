import React from 'react'
import { motion } from 'framer-motion'
import clsx from 'clsx'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  className?: string
}

const Input: React.FC<InputProps> = ({ className, ...props }) => {
  return (
    <motion.div
      whileFocus={{ scale: 1.02 }}
      className="relative"
    >
      <input
        className={clsx(
          'w-full px-4 py-2 border border-neutral-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-400 focus:border-transparent bg-white text-neutral-900 placeholder-neutral-400',
          className
        )}
        {...props}
      />
    </motion.div>
  )
}

export default Input