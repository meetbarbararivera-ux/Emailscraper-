import React from 'react'
import { motion } from 'framer-motion'

interface Column {
  header: string
  accessor: string
}

interface TableProps {
  columns: Column[]
  data: any[]
  renderCell?: (item: any, accessor: string) => React.ReactNode
}

const Table: React.FC<TableProps> = ({ columns, data, renderCell }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="overflow-x-auto"
    >
      <table className="min-w-full divide-y divide-neutral-200">
        <thead className="bg-neutral-100">
          <tr>
            {columns.map((column) => (
              <th
                key={column.accessor}
                className="px-6 py-3 text-left text-xs font-medium text-neutral-800 uppercase tracking-wider"
              >
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-neutral-200">
          {data.map((item, index) => (
            <tr key={index} className="hover:bg-neutral-50">
              {columns.map((column) => (
                <td
                  key={column.accessor}
                  className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900"
                >
                  {renderCell ? renderCell(item, column.accessor) : item[column.accessor] || 'N/A'}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </motion.div>
  )
}

export default Table