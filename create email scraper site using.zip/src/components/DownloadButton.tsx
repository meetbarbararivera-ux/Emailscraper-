import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Download } from 'lucide-react'
import Button from './ui/Button'
import Select from './ui/Select'
import { useSearchStore } from '../store/searchStore'
import { exportToCSV, exportToTXT, exportToExcel } from '../lib/exportUtils'

const downloadOptions = [
  { value: 'csv', label: 'CSV' },
  { value: 'txt', label: 'TXT' },
  { value: 'excel', label: 'Excel' },
]

const DownloadButton: React.FC = () => {
  const [format, setFormat] = useState('csv')
  const { results } = useSearchStore()

  const handleDownload = () => {
    if (results.length === 0) return

    const filename = `scraper_results_${new Date().toISOString()}.${format}`
    switch (format) {
      case 'csv':
        exportToCSV(results, filename)
        break
      case 'txt':
        exportToTXT(results, filename)
        break
      case 'excel':
        exportToExcel(results, filename)
        break
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mt-6 flex gap-4 items-center"
    >
      <Select
        options={downloadOptions}
        value={format}
        onChange={(e) => setFormat(e.target.value)}
        disabled={results.length === 0}
      />
      <Button
        onClick={handleDownload}
        disabled={results.length === 0}
        className="flex items-center gap-2"
      >
        <Download className="w-5 h-5" />
        Download
      </Button>
    </motion.div>
  )
}

export default DownloadButton