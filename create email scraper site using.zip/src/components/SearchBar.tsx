import React, { useState } from 'react'
import { motion } from 'framer-motion'
import Button from './ui/Button'
import Input from './ui/Input'
import Select from './ui/Select'
import { Search, Loader2 } from 'lucide-react'
import { useSearch } from '../hooks/useSearch'

const searchEngines = [
  { value: 'google', label: 'Google' },
  { value: 'bing', label: 'Bing' },
  { value: 'duckduckgo', label: 'DuckDuckGo' },
  { value: 'webscrapeapi', label: 'WebScrapeAPI' },
]

const SearchBar: React.FC = () => {
  const [query, setQuery] = useState('')
  const [engine, setEngine] = useState('google')
  const { search, isLoading } = useSearch()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      search(query, engine)
    }
  }

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onSubmit={handleSubmit}
      className="flex flex-col sm:flex-row gap-4 bg-white p-6 rounded-lg shadow-lg"
    >
      <Input
        type="text"
        placeholder="Enter query (e.g., doctor California @gmail.com)"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="flex-1"
        disabled={isLoading}
      />
      <Select
        options={searchEngines}
        value={engine}
        onChange={(e) => setEngine(e.target.value)}
        disabled={isLoading}
      />
      <Button
        type="submit"
        disabled={isLoading || !query.trim()}
        className="flex items-center gap-2"
      >
        {isLoading ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Search className="w-5 h-5" />
        )}
        Search
      </Button>
    </motion.form>
  )
}

export default SearchBar