import React from 'react'
import { motion } from 'framer-motion'
import { useSearchStore } from '../store/searchStore'
import Table from './ui/Table'

const ResultsTable: React.FC = () => {
  const { results } = useSearchStore()

  const columns = [
    { header: 'Name', accessor: 'name' },
    { header: 'Address', accessor: 'address' },
    { header: 'Email', accessor: 'email' },
    { header: 'Phone', accessor: 'phone' },
    { header: 'Links', accessor: 'links' },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-lg shadow-lg overflow-hidden"
    >
      <Table
        columns={columns}
        data={results}
        renderCell={(item: any, accessor: string) => {
          if (accessor === 'links') {
            return (
              <div className="flex flex-col gap-1">
                {item.links.map((link: string, index: number) => (
                  <a
                    key={index}
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary-400 hover:underline"
                  >
                    {link}
                  </a>
                ))}
              </div>
            )
          }
          return item[accessor] || 'N/A'
        }}
      />
    </motion.div>
  )
}

export default ResultsTable