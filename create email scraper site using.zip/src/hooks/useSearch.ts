import { useCallback } from 'react'
import { useSearchStore } from '../store/searchStore'

interface ScrapeResult {
  name: string
  address: string
  email: string
  phone: string
  links: string[]
}

export const useSearch = () => {
  const { setResults, setIsLoading, setError } = useSearchStore()

  const search = useCallback(async (query: string, engine: string) => {
    setIsLoading(true)
    setError(null)
    setResults([])

    try {
      // Simulated API call to WebScrapeAPI or search engine
      const response = await fetch(
        `https://api.webscrapeapi.com/search?q=${encodeURIComponent(query)}&engine=${engine}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            // Add API key if required: 'Authorization': `Bearer ${import.meta.env.VITE_SCRAPE_API_KEY}`,
          },
        }
      )

      if (!response.ok) {
        throw new Error('Failed to fetch search results')
      }

      const data = await response.json()

      // Simulate pagination and data extraction
      const results: ScrapeResult[] = []
      let page = 1
      const maxPages = 5 // Simulated max pages to avoid infinite loops

      while (page <= maxPages) {
        const pageData = await fetch(
          `https://api.webscrapeapi.com/search?q=${encodeURIComponent(query)}&engine=${engine}&page=${page}`,
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )

        if (!pageData.ok) break

        const pageResults = await pageData.json()
        if (pageResults.length === 0) break

        pageResults.forEach((item: any) => {
          results.push({
            name: item.name || 'Unknown',
            address: item.address || 'N/A',
            email: item.email || 'N/A',
            phone: item.phone || 'N/A',
            links: item.links || [],
          })
        })

        page++
      }

      setResults(results)
    } catch (err) {
      setError('An error occurred while scraping. Please try again.')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }, [setResults, setIsLoading, setError])

  return { search, isLoading: useSearchStore((state) => state.isLoading) }
}